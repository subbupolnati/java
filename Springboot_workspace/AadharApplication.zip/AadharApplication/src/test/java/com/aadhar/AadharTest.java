package com.aadhar;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.aadhar.model.Aadhar;
//@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class AadharTest {
	@LocalServerPort
	int port;
	@Autowired
	TestRestTemplate template;
	@BeforeEach
	void setUp() throws Exception {
	}
	@Test
	 public void getAdharTest()
	 {
		 //String url="http://localhost:8080/aadhar?";
		String url="http://localhost:"+port+"/aadhar?";
		 UriComponents builder=UriComponentsBuilder.fromHttpUrl(url).queryParam("aadharNumber","8171").build();
		 HttpEntity<Aadhar> request=new HttpEntity<Aadhar>(null,null);
		 ResponseEntity<Aadhar[]> res=template.exchange (builder.toString(), HttpMethod.GET,request,Aadhar[].class);
		 System.out.println("Response from the Server"+res.getBody());
		 assertEquals(HttpStatus.OK, res.getStatusCode());
	 }
	 @Test
	 public void getAllAadharTest() {
		 
		 //String url="http://localhost:8080/aadhar";
		 String url="http://localhost:"+port+"/aadhar";
		 UriComponents builder=UriComponentsBuilder.fromHttpUrl(url).build();
		 HttpEntity<Aadhar> request=new HttpEntity<Aadhar>(null,null);
		 ResponseEntity<Aadhar[]> res=template.exchange (builder.toString(), HttpMethod.GET,request,Aadhar[].class);
		 System.out.println("Response from the Server"+res.getBody().toString());
		 assertEquals(HttpStatus.OK, res.getStatusCode());
	 }
	 @Test
	 public void addAadharTest() {
		 Aadhar ad=new Aadhar("123456","veera");
		 ResponseEntity<Aadhar> response=this.template. postForEntity("http://localhost:"+port+"/aadhar", ad,Aadhar.class);
		 assertEquals(HttpStatus.CREATED,response.getStatusCode());
	 }
	 @Test
	 public void updateAadhar() {
		 Aadhar ad=new Aadhar("123456","veera");
		 ad.setName("subbu");
		 String url="http://localhost:"+port+"/aadhar/123456";
		 UriComponents builder=UriComponentsBuilder.fromHttpUrl(url).build();
		 HttpEntity<Aadhar> entity=new HttpEntity<Aadhar>(ad,null);
		 ResponseEntity<Aadhar[]>response=template.exchange(builder.toString(),HttpMethod.PUT,entity,Aadhar[].class);
		 System.out.println("Response update from the server"+response.getBody());
		 assertEquals(HttpStatus.OK,response.getStatusCode());
	 }
	 @Test
	 public void deleteAadharTest()
	 {
		 //String url="http://localhost:8080/aadhar?";
		 String url="http://localhost:"+port+"/aadhar?";
		 UriComponents builder=UriComponentsBuilder.fromHttpUrl(url).queryParam("aid","8171").build();
		 HttpEntity request=new HttpEntity (null,null);
		 ResponseEntity<Aadhar>res=template.exchange (builder.toString(), HttpMethod.DELETE,request,Aadhar.class);
		 System.out.println("Response from the Server"+res.getBody());
		 assertEquals(200, res.getStatusCodeValue());
	 }
		/*
		 * @Test void test() { String url="http:localhost:8080/aadhar"; UriComponents
		 * builder=UriComponentsBuilder.fromHttpUrl(url).build(); ResponseEntity
		 * res=template.exchange(builder.toString(),HttpMethod.GET, null,Aadhar.class);
		 * System.out.println("Response from the server"+res.getBody());
		 * assertEquals(HttpStatus.OK,res.getStatusCode()); }
		 */

}
