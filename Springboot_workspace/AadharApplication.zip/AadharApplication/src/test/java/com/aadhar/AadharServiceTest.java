package com.aadhar;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import com.aadhar.model.Aadhar;
import com.aadhar.respository.AadharRepsoitory;
import com.aadhar.service.AadharService;
class AadharServiceTest {

	@Mock
	AadharRepsoitory aadharRepository;
	@Autowired
	AadharService aadharService;
	List<Aadhar> al;
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		aadharService=new AadharService(this.aadharRepository);
		al=new ArrayList<Aadhar>();
		al.add(new Aadhar("8171","subbu"));
		al.add(new Aadhar("10115","ssss"));
	}
	@Test
	void testVerifyFindAllAadharList() {
		aadharService.getAllAadharDetails();
		verify(this.aadharRepository).findAll();
	}
	@Test
	void testEmployeeId() {
		Aadhar a=new Aadhar("8171","subbu");
		when(aadharRepository.save(a)).thenReturn(a);
		assertNotNull(a);
	}
	@Test
	void testVerifyFindAllAadhar() {
		aadharService.getAllAadharDetails();
		assertEquals(2,al.size());
	}
	@Test
	void testGetAadhar() {
		when(aadharRepository.getById("8171")).thenReturn(new Aadhar("8171","harshi"));
		Aadhar a=aadharRepository.getById("8171");
		assertEquals("8171",a.getAadharNumber());	
	}
	@Test 
	void testDelete() {
		aadharService.deleteAadhar("8171");
		assertTrue(true);
	}
	@Test 
	void testExist() {
		Aadhar a=new Aadhar("8171","subbu");
		boolean b=aadharRepository.existsById(a.getAadharNumber());
		assertThat(b).isFalse();
	}
	/*
	 * @Test void testUpdate() { Aadhar a=new Aadhar("8171","subbu");
	 * a.setName("veera"); when(aadharService.updateAadhar(a,"8171")).thenReturn(a);
	 * assertNotEquals("veera",a.getName()); }
	 */
	
	
}
