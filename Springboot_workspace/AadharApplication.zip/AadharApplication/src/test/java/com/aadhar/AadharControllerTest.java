package com.aadhar;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import com.aadhar.controller.AadharController;
import com.aadhar.exceptions.AadharNotFoundException;
import com.aadhar.model.Aadhar;
import com.aadhar.respository.AadharRepsoitory;
import com.aadhar.service.AadharService;
import com.fasterxml.jackson.databind.ObjectMapper;
@WebMvcTest(AadharController.class)
class AadharControllerTest {

	@MockBean
	AadharRepsoitory aadharRepository;
	@Autowired
	AadharController aadharController;
	@Autowired
	MockMvc mvc;
	@MockBean
	AadharService aadharService;
	
	@BeforeEach
	void setUp() throws Exception {
	}
	@Test
	void testString() throws Exception
	{
		mvc.perform(get("/home"))
		.andExpect(content().string(containsString("this")))
		.andDo(print());	
	}
	
	@Test
	void testAadharSearchById() throws Exception {
		Aadhar a=new Aadhar();
		a.setAadharNumber("8171");
		a.setName("veera subrahmanyam");
		aadharService.createAadhar(a);
		System.out.println(a);
		when(aadharService.getAadhar("8171")).thenReturn(a);
		mvc.perform(MockMvcRequestBuilders.get("/aadhar/8171"))
		.andExpect(jsonPath("$.aadharNumber").value("8171"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.name").value("veera subrahmanyam"))
		.andExpect(status().isOk())
		.andDo(print());
		System.out.println("Aadhar is Exist");
	}
	@Test
	void testAddnewAadhar() throws Exception {
		Aadhar a=new Aadhar("8171","subbu");;
		aadharService.createAadhar(a);
		when(aadharService.createAadhar(a)).thenReturn(a);
		MockHttpServletRequestBuilder mockRequest = MockMvcRequestBuilders.post("/aadhar")
	            .contentType("Application/json;charset=UTF-8")
	            .accept("Application/json")
	            .content(new ObjectMapper().writeValueAsString(a));
		mvc.perform(mockRequest)
		.andDo(print());
	}
	@Test
	void testAllAadhar() throws Exception {
		ArrayList<Aadhar> al=new ArrayList<Aadhar>();
		al.add(new Aadhar("8171","subbu"));
		al.add(new Aadhar("10115","ssss"));
		when(aadharService.getAllAadharDetails()).thenReturn(al);
		MvcResult result=mvc.perform(get("/aadhar"))
				.andExpect(status().isOk()).andReturn();
		String actualResponce=result.getResponse().getContentAsString();
		System.out.println("actualResponse is"+actualResponce);
		String expectedResult=new ObjectMapper().writeValueAsString(al);
		System.out.println("Expected Result is"+expectedResult);
		assertThat(actualResponce).isEqualTo(expectedResult);
	}
	@Test
	void testDeleteAadhar() throws Exception {
		Aadhar a=new Aadhar();
		a.setAadharNumber("12345");
		a.setName("subbu");
		Mockito.doNothing().when(aadharService).deleteAadhar("12345");;
		mvc.perform(delete("/aadhar/12345"))
		.andExpect(status().isOk());
		Mockito.verify(aadharService,times(1)).deleteAadhar("12345");
	}
	@Test
	void testNoEmployeeFound() throws Exception {
		when(aadharService.getAadhar("81455")).thenThrow(new AadharNotFoundException("No Aadhar Id Found"));
		mvc.perform(MockMvcRequestBuilders.get("/aadhar/81455"))
		.andExpect(status().isNotFound())
		.andDo(print());
	}
	@Test
	void testUpdateEmployee() throws Exception {
		Aadhar a=new Aadhar("8171","subbu");
		a.setName("veera");
		aadharService.updateAadhar(a,"8171");
		when(aadharService.updateAadhar(a,"8171")).thenReturn(a);
		MockHttpServletRequestBuilder mockRequest = MockMvcRequestBuilders.put("/aadhar/8171")
	            .contentType("Application/json;charset=UTF-8")
	            .accept("Application/json")
	            .content(new ObjectMapper().writeValueAsString(a));
		mvc.perform(mockRequest)
		.andDo(print());
	}

}
