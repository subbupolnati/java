package com.aadhar.controller;

import java.net.URI;
import java.util.List;
import org.slf4j.*;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.aadhar.model.Aadhar;
import com.aadhar.service.AadharService;

@RestController
public class AadharController {
	Logger logger=LoggerFactory.getLogger("AadharController.class");
	@Autowired
	private AadharService aadharService;

	public AadharService getAadharService() {
		return aadharService;
	}

	public void setAadharService(AadharService aadharService) {
		this.aadharService = aadharService;
	}
	@GetMapping("/home")
	public String home() {
		logger.trace("Information is traced");
		logger.info("Hello World Information Generated");
		logger.debug("Application is in DEBUG Mode");
		logger.warn("Generating Warning .....");
		return "this is home page";
	}
	@GetMapping("/aadhar")
	public List<Aadhar> getAllAadharDetails() {
		return aadharService.getAllAadharDetails();
	}
	@PostMapping("/aadhar")
	public ResponseEntity<Aadhar>createAadhar(@RequestBody Aadhar aadhar){
		Aadhar a=aadharService.createAadhar(aadhar);
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{aadharNumber}").buildAndExpand(a.getAadharNumber()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	@GetMapping("/aadhar/{aadharNumber}")
	public Aadhar getAadhar(@PathVariable("aadharNumber") String aadharNumber) {
		return aadharService.getAadhar(aadharNumber);
	}
	@PutMapping("/aadhar/{aid}")
	public Aadhar uploadAadhar(@RequestBody Aadhar aadhar,@PathVariable("aid") String aadharNumber) {
		return aadharService.updateAadhar(aadhar,aadharNumber);
	}
	@DeleteMapping("/aadhar/{aid}")
	public void deleteAadhar(@PathVariable("aid") String aadharNumber) {
		aadharService.deleteAadhar(aadharNumber);
	}
}
