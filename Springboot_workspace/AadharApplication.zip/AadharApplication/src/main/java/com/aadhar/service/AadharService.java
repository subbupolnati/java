package com.aadhar.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aadhar.exceptions.AadharNotFoundException;
import com.aadhar.model.Aadhar;
import com.aadhar.respository.AadharRepsoitory;

@Service
public class AadharService {
	Logger logger=LoggerFactory.getLogger("AadharService");
	@Autowired
	private AadharRepsoitory aadharRepository;

	public AadharService(AadharRepsoitory aadharRepository) {
		super();
		this.aadharRepository = aadharRepository;
	}

	public AadharRepsoitory getAadharRepository() {
		return aadharRepository;
	}

	public void setAadharRepository(AadharRepsoitory aadharRepository) {
		this.aadharRepository = aadharRepository;
	}
	public Aadhar createAadhar(Aadhar aadhar) {
		
		return aadharRepository.save(aadhar);
	}
	public List<Aadhar>getAllAadharDetails(){
		logger.info("Get ALl the Aadhar Details");
		return aadharRepository.findAll();
	}
	public Aadhar getAadhar(String aadharNumber) {
		Optional<Aadhar>optional=aadharRepository.findById(aadharNumber);
		Aadhar aadhar=null;
		if(optional.isPresent()) {
			aadhar=optional.get();
			return aadhar;
		}
		else
			throw new AadharNotFoundException("Aadhar number not Found");
	}
	public Aadhar updateAadhar(Aadhar aadhar,String aadharNumber) {
		Optional<Aadhar>optional=aadharRepository.findById(aadharNumber);
		if(optional.isPresent()) {
			aadhar.setAadharNumber(aadharNumber);
			return aadharRepository.save(aadhar);
		}
		else
			throw new AadharNotFoundException("Aadhar number not Found");
	}
	public void deleteAadhar(String aadharNumber) {
		try {
			aadharRepository.deleteById(aadharNumber);
		}catch(Exception e) {
			throw new AadharNotFoundException("Aadhar number not Found");
		}
			
	}
}
