package com.aadhar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AadharApplication {
	public static void main(String[] args) {
		SpringApplication.run(AadharApplication.class, args);
	}

}
