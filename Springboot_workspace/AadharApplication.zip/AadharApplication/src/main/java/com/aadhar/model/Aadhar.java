package com.aadhar.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Aadhar {

	@Id
	private String aadharNumber;
	private String name;
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Aadhar [aadharNumber=" + aadharNumber + ", name=" + name + "]";
	}
	public Aadhar(String aadharNumber, String name) {
		super();
		this.aadharNumber = aadharNumber;
		this.name = name;
	}
	public Aadhar() {
		super();
		// TODO Auto-generated constructor stub
	}
}
