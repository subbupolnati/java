package com.healthcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareManagementSystemApplication.class, args);
	}

}
