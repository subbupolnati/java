package com.employee_timesheet.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.employee_timesheet.model.EmployerModel;

/**
 * This employer service is used to define employer business logic methods
 *
 */
@Service
public interface EmployerService {

	/**
	 * This method is used to save list of employers
	 * 
	 * @param employerList
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveEmployers(List<EmployerModel> employerList);

	/**
	 * This method is used to getting all employers
	 * 
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getAllEmployers();

	/**
	 * This method is used to update employer
	 * 
	 * @param employerModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updateEmployer(EmployerModel employerModel);

	/**
	 * This method is used to delete employer by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> deleteEmployer(int userId);

	/**
	 * This method is used to get employer by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getEmployer(int userId);
}
