package com.employee_timesheet.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.employee_timesheet.model.UserModel;

/**
 * This UserService interface executing abstract methods
 */
@Service
public interface UserService {

	/**
	 * This method is used to save admin 
	 * @param user
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveAdmin(UserModel user);
	/**
	 * This method is used to save List of users
	 * 
	 * @param usersList
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveUsers(List<UserModel> usersList);

	/**
	 * This method is used to update user
	 * 
	 * @param userModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updateUser(UserModel userModel);

	/**
	 * This method is used to delete user by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> deleteUser(int userId);

	/**
	 * This method is used to change user password by official mail
	 * 
	 * @param officialMail
	 * @param oldPassword
	 * @param newPassword
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updatePassword(String officialMail, String oldPassword, String newPassword);

	/**
	 * This method is used to find users by role with pagination
	 * 
	 * @param role
	 * @param pageNo
	 * @param pageSize
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getUsersByRole(String role, int pageNo, int pageSize);

	/**
	 * This method is used to upload user profile pic by user id
	 * 
	 * @param userId
	 * @param file
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> uploadProfilePic(int userId, MultipartFile file);

	/**
	 * This method is used to fetch user profile pic by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getProfilePic(int userId);

	/**
	 * This method is used to fetch user details by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getUser(int userId);

	/**
	 * This method is used to getting all users
	 * 
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getAllUsers();

}
