package com.employee_timesheet.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.employee_timesheet.model.ClientModel;

/**
 * This ClientService Interface define client service abstract methods
 *
 */
@Service
public interface ClientService {
	/**
	 * This method is used to save client
	 * @param clientModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveClient(ClientModel clientModel);
	/**
	 * This method is used to get all clients List
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getAllClients();
	/**
	 * This method is used to update client
	 * @param clientModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updateClient(ClientModel clientModel);
	/**
	 * This method is used to delete client by client id
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> deleteClient(int clientId);
	
	/**
	 * This method is used to fetch client by client id
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getClient(int clientId);
}
