package com.employee_timesheet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employee_timesheet.model.EmployerModel;
import com.employee_timesheet.service.EmployerService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * This employer controller is used to store data
 *
 */
@RestController
@RequestMapping("/${controller.path}")
@Slf4j
@Data
public class EmployerController {

	@Autowired
	private EmployerService employerService;

	/**
	 * @apiNote This api is used to save list of employers
	 * @param employerList
	 * @return ResponseEntity<?>
	 */
	@PostMapping("/employer/saveemployers")
	public ResponseEntity<?> saveEmployers(@RequestBody List<EmployerModel> employerList) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = employerService.saveEmployers(employerList);
		long endTime = System.currentTimeMillis();
		log.info("EmployerController : saveEmployers - Time taken for executing save employers " + (endTime - startTime)
				+ " ms");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to getting all employers list
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/employer/getemployers")
	public ResponseEntity<?> getAllEmployers() {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> resposneEntity = employerService.getAllEmployers();
		long endTime = System.currentTimeMillis();
		log.info("EmployerController : getAllEmployers - Time taken for executing getting all employers "
				+ (endTime - startTime) + " ms");
		return resposneEntity;
	}

	/**
	 * @apiNote This api is used to update employer
	 * @param employerModel
	 * @return ResponseEntity<?>
	 */
	@PutMapping("/employer/update")
	public ResponseEntity<?> updateEmployer(@RequestBody EmployerModel employerModel) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> resposneEntity = employerService.updateEmployer(employerModel);
		long endTime = System.currentTimeMillis();
		log.info("EmployerController : updateEmployer - Time taken for executing update employer "
				+ (endTime - startTime) + " ms");
		return resposneEntity;
	}

	/**
	 * @apiNote This api is used to delete employer by user id
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@DeleteMapping("/employer/delete")
	public ResponseEntity<?> deleteEmployer(@RequestParam("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = employerService.deleteEmployer(userId);
		long endTime = System.currentTimeMillis();
		log.info("EmployerController : deleteEmployer - Time taken for executing delete employer by user id"
				+ (endTime - startTime) + "ms");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to fetch employer by user id
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/employer/get")
	public ResponseEntity<?> getEmployer(@RequestParam("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = employerService.getEmployer(userId);
		long endTime = System.currentTimeMillis();
		log.info("EmployerController : getEmployer - Time taken for executing get employer by user id"
				+ (endTime - startTime) + "ms");
		return responseEntity;
	}
}
