package com.employee_timesheet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.employee_timesheet.model.ClientModel;
import com.employee_timesheet.service.ClientService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * This client controller is used to execute client api's
 *
 */
@RestController
@RequestMapping("/${controller.path}")
@Slf4j
@Data
public class ClientController {

	@Autowired
	private ClientService clientService;

	/**
	 * @apiNote This api is used to save client
	 * @param clientModel
	 * @return ResponseEntity<?>
	 */
	@PostMapping("/client/save")
	public ResponseEntity<?> saveClient(@RequestBody ClientModel clientModel) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = clientService.saveClient(clientModel);
		long endTime = System.currentTimeMillis();
		log.info(
				"ClientController : saveClient -Time taken for executing save client " + (endTime - startTime) + " ms");
		return responseEntity;
	}

	/**
	 * This api is used to getting all clients
	 * 
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/client/getallclients")
	public ResponseEntity<?> getAllClients() {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = clientService.getAllClients();
		long endTime = System.currentTimeMillis();
		log.info("ClientController : getAllClients -Time taken for executing getting all clients "
				+ (endTime - startTime) + " ms");
		return responseEntity;
	}

	/**
	 * This method is used to update client
	 * 
	 * @param clientModel
	 * @return ResponseEntity<?
	 */
	@PutMapping("/client/update")
	public ResponseEntity<?> updateClient(@RequestBody ClientModel clientModel) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = clientService.updateClient(clientModel);
		long endTime = System.currentTimeMillis();
		log.info("ClientController : updateClient -Time taken for executing update client " + (endTime - startTime)
				+ " ms");
		return responseEntity;
	}

	/**
	 * This method is used to delete client by client id
	 * 
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	@DeleteMapping("/client/delete")
	public ResponseEntity<?> deleteClient(@RequestParam("clientId") int clientId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = clientService.deleteClient(clientId);
		long endTime = System.currentTimeMillis();
		log.info("ClientController : deleteClient -Time taken for executing delete client " + (endTime - startTime)
				+ " ms");
		return responseEntity;
	}

	/**
	 * This method is used to fetch client by client id
	 * 
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/client/get")
	public ResponseEntity<?> getClient(@RequestParam("clientId") int clientId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = clientService.getClient(clientId);
		long endTime = System.currentTimeMillis();
		log.info("ClientController : getClient -Time taken for executing get client " + (endTime - startTime) + " ms");
		return responseEntity;
	}
}
