package com.employee_timesheet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.employee_timesheet.model.UserModel;
import com.employee_timesheet.service.UserService;
import lombok.extern.slf4j.Slf4j;

/**
 * This UserController class executes user api's
 */
@RestController
@RequestMapping("/${controller.path}")
@Slf4j
public class UserController {
	// this Autowired annotations inject UserService dependencies
	@Autowired
	private UserService userService;
	/**
	 * @apiNote This api is used to save admin
	 * @param user
	 * @return ResponseEntity<?>
	 */
	@PostMapping("/save/admin")
	public ResponseEntity<?>saveAdmin(@RequestBody UserModel user){
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.saveAdmin(user);
		long endTime = System.currentTimeMillis();
		log.info("UserController : saveAdmin - Time taken for executing save admin " + (endTime - startTime) + " ms");
		return responseEntity;
	}
	/**
	 * @apiNote This api is used to save list of users
	 * @param usersList
	 * @return ResponseEntity<?>
	 */
	@PostMapping("/save/users")
	public ResponseEntity<?> saveUsers(@RequestBody List<UserModel> usersList) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.saveUsers(usersList);
		long endTime = System.currentTimeMillis();
		log.info("UserController : saveUsers - Time taken for executing save users " + (endTime - startTime) + " ms");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to update user
	 * @param userModel
	 * @return ResponseEntity<?>
	 */
	@PutMapping("/update/user")
	public ResponseEntity<?> updateUser(@RequestBody UserModel userModel) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.updateUser(userModel);
		long endTime = System.currentTimeMillis();
		log.info("UserController : updateUser - Time taken for executing update user " + (endTime - startTime) + "ms");
		return responseEntity;
	}

	/**
	 * @apiNote This api used to delete user by user id
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@DeleteMapping("/delete/user")
	public ResponseEntity<?> deleteUser(@RequestParam("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.deleteUser(userId);
		long endTime = System.currentTimeMillis();
		log.info("UserController : deleteUser - Time taken for executing delete user by user id" + (endTime - startTime)
				+ "ms");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to change user password by official mail
	 * @param officialMail
	 * @param oldPassword
	 * @param newPassword
	 * @return ResponseEntity<?>
	 */
	@PutMapping("/updatepassword")
	public ResponseEntity<?> updatePassword(@RequestParam("officialMail") String officialMail,
			@RequestParam("oldPassword") String oldPassword, @RequestParam("newPassword") String newPassword) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.updatePassword(officialMail, oldPassword, newPassword);
		long endTime = System.currentTimeMillis();
		log.info("UserController : updatePassword - Time taken for executing change user password by official mail "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to fetching users by role with pagination
	 * @param role
	 * @param pageNo
	 * @param pageSize
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/getusers")
	public ResponseEntity<?> getUsersByRole(@RequestParam("role") String role, @RequestParam("pageNo") int pageNo,
			@RequestParam("pageSize") int pageSize) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getUsersByRole(role, pageNo, pageSize);
		long endTime = System.currentTimeMillis();
		log.info("UserController : getUsersByRole - Time taken for executing get users by role " + (endTime - startTime)
				+ "ms ");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to upload user profile pic by user id
	 * @param userId
	 * @param file
	 * @return ResponseEntity<?>
	 */
	@PostMapping(value = "/uploadprofile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> uploadProfilePic(@RequestParam("userId") int userId,
			@RequestParam("profile") MultipartFile file) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.uploadProfilePic(userId, file);
		long endTime = System.currentTimeMillis();
		log.info("UserController : uploadProfilePic - Time taken for executing upload user profile pic by user id "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to fetch user profile pic by user id
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@GetMapping(value = "/getprofilepic", produces = MediaType.IMAGE_JPEG_VALUE)
	public ResponseEntity<?> getProfilePic(@RequestParam("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getProfilePic(userId);
		long endTime = System.currentTimeMillis();
		log.info("UserController : getProfilePic - Time taken for executing fetch user profile pic bu user id "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to fetch user data by userid
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@GetMapping(value = "/getuser")
	public ResponseEntity<?> getUser(@RequestParam("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getUser(userId);
		long endTime = System.currentTimeMillis();
		log.info("UserController : getUser - Time taken for executing fetch user by user id " + (endTime - startTime)
				+ "ms ");
		return responseEntity;
	}

	/**
	 * @apiNote This api is used to getting all users
	 * @return ResponseEntity<?>
	 */
	@GetMapping("/get/users")
	public ResponseEntity<?> getAllUsers() {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getAllUsers();
		long endTime = System.currentTimeMillis();
		log.info("UserController : getAllUsers - Time taken for executing getting All Users " + (endTime - startTime)
				+ " ms");
		return responseEntity;
	}
}
