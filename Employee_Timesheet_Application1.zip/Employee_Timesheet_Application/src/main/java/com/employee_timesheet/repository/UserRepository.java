package com.employee_timesheet.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.employee_timesheet.entity.User;

/**
 * This user repository interface execute database operations
 *
 */
@Repository

public interface UserRepository extends JpaRepository<User,Integer>{
	/**
	 * This method is used to find user by official mail  
	 * @param username
	 * @return User
	 */
	@Query(value = "SELECT * FROM USERS u WHERE u.official_mail = ?1", nativeQuery = true)
	public User findByLoginOfficialMail(String officialMail);
	/**
	 * This method is used to find user by official mail 
	 * @param officialMail
	 * @return Optional<User>
	 */
	public Optional<User> findByOfficialMail(String officialMail);
	/**This method is used to find user by role with pagination
	 * @param roles
	 * @param pageable
	 * @return Page<User>
	 */
	Page<User> findByRolesContaining(String role, Pageable pageable);
}
