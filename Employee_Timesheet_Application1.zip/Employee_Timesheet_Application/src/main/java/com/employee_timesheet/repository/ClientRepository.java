package com.employee_timesheet.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee_timesheet.entity.Client;

/**
 * This clieny repository interface execute database operations
 *
 */
@Repository
public interface ClientRepository extends JpaRepository<Client, Integer>{

	/**
	 * This method is used to find client by email
	 * @param email
	 * @return Optional<Client>
	 */
	public Optional<Client> findByEmail(String email);
}
