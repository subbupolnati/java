package com.employee_timesheet.serviceimpl;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.employee_timesheet.entity.Client;
import com.employee_timesheet.entity.User;
import com.employee_timesheet.model.ConstantMessage;
import com.employee_timesheet.model.UserModel;
import com.employee_timesheet.model.Response;
import com.employee_timesheet.repository.ClientRepository;
import com.employee_timesheet.repository.UserRepository;
import com.employee_timesheet.service.UserService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * This UserServiceImpl class excutes user business logics
 */
@Service
@Data
@Slf4j
public class UserServiceImpl implements UserService {
	// This Autowired annotations inject UserRepository dependencies
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private ClientRepository clientRepository;
	// This Autowired annotations inject BCryptPasswordEncoder dependencies using
	// password encrypt
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	/**
	 * This method is used to save admin
	 * 
	 * @param user
	 * @return ResponseEntity<?>
	 */
	
	public ResponseEntity<?> saveAdmin(UserModel user) {
		try {
			log.info("UserServiceImpl : saveAdmin");
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			userRepository.save(processUser(user));
			log.info("UserServiceImpl : saveAdmin - Admin " + ConstantMessage.SAVE + user.getOfficialMail());
			return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.SAVE);
		} catch (Exception e) {
			log.error("UserServiceImpl : saveAdmin - " + ConstantMessage.EXCEPTION_FOUND + "save admin :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to save list of users
	 * 
	 * @param usersList
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveUsers(List<UserModel> usersList) {
		List<UserModel> failureUserList = new ArrayList<UserModel>();
		List<UserModel> successUserList = new ArrayList<UserModel>();
		boolean status = false;
		try {
			log.info("UserServiceImpl : saveUsers");
			for (UserModel user : usersList) {
				Optional<User> optionalUser = isUserPresent(user.getOfficialMail());
				if (optionalUser.isEmpty()) {
					if (user.getClient() != null) {
						status = isClientPresent(user.getClient().getClientId());
					} // This if condition check client exist or not
					if (user.getClient() == null || status == true) {
						user.setPassword(passwordEncoder.encode(user.getPassword()));
						userRepository.save(processUser(user));
						user.setMessage(ConstantMessage.USER + ConstantMessage.SAVE);
						log.info("UserServiceImpl : saveUsers - " + ConstantMessage.USER + ConstantMessage.SAVE
								+ user.getOfficialMail());
						successUserList.add(user);
						// This condtion check client is active or not
					} else if (status == true && !user.getClient().isActive()) {
						log.error("UserServiceImpl : saveUsers - " + ConstantMessage.CLIENT + ConstantMessage.INACTIVE
								+ user.getClient().getClientId());
						user.setMessage(
								ConstantMessage.CLIENT + ConstantMessage.INACTIVE + user.getClient().getClientId());
						failureUserList.add(user);
					} else {
						log.error("UserServiceImpl : saveUsers - " + ConstantMessage.CLIENT + ConstantMessage.NOTFOUND
								+ user.getClient().getClientId());
						user.setMessage(
								ConstantMessage.CLIENT + ConstantMessage.NOTFOUND + user.getClient().getClientId());
						failureUserList.add(user);
					}
				} else {
					log.error("UserServiceImpl : saveUsers - " + ConstantMessage.USER + ConstantMessage.EXIST
							+ user.getOfficialMail());
					user.setMessage(ConstantMessage.USER + ConstantMessage.EXIST);
					failureUserList.add(user);
				}
			}
			Response response = new Response(usersList.size(), successUserList.size(), failureUserList.size(),
					successUserList, failureUserList);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			log.error("UserServiceImpl : saveUsers - " + ConstantMessage.EXCEPTION_FOUND + "save users :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to update user
	 * 
	 * @param userModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updateUser(UserModel userModel) {
		try {
			log.info("UserServiceImpl : updateUser");
			boolean status = false;
			Optional<User> optional = userRepository.findById(userModel.getUserId());
			if (optional.isPresent()) {
				if (userModel.getClient() != null) {
					// This statement check client present or not
					status = isClientPresent(userModel.getClient().getClientId());
				}
				// This statement check official mail exists or not
				Optional<User> optionalUser = isUserPresent(userModel.getOfficialMail());
				if (optionalUser.isEmpty() || optional.get().getOfficialMail().equals(userModel.getOfficialMail())) {
					if (status == false) {// This if condition check clent status
						log.error("UserServiceImpl : updateUser - " + ConstantMessage.CLIENT + ConstantMessage.NOTFOUND
								+ userModel.getClient().getClientId());
						return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ConstantMessage.CLIENT
								+ ConstantMessage.NOTFOUND + userModel.getClient().getClientId());
						// This Condition check clientis active or not
					} else if (status == true && !optional.get().getClient().isActive()) {
						log.error("UserServiceImpl : updateUser - " + ConstantMessage.CLIENT + ConstantMessage.INACTIVE
								+ userModel.getClient().getClientId());
						return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ConstantMessage.CLIENT
								+ ConstantMessage.INACTIVE + userModel.getClient().getClientId());
					}
					userRepository.save(processUserWithProfile(userModel, optional));
					log.info("UserServiceImpl : updateUser - " + ConstantMessage.USER + ConstantMessage.UPDATE
							+ userModel.getUserId());
					return ResponseEntity.status(HttpStatus.OK)
							.body(ConstantMessage.USER + ConstantMessage.UPDATE + userModel.getUserId());
				} else {
					log.error("UserService : updateUser - " + ConstantMessage.USER + ConstantMessage.EXIST
							+ userModel.getOfficialMail());
					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(ConstantMessage.USER + ConstantMessage.EXIST + userModel.getOfficialMail());
				}
			} else {
				log.error("UserServiceImpl : updateUser -" + ConstantMessage.USER + ConstantMessage.NOTFOUND
						+ userModel.getUserId());
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + userModel.getUserId());
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : updateUser - " + ConstantMessage.EXCEPTION_FOUND + "update user :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to delete user by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> deleteUser(int userId) {
		try {
			log.info("UserServiceImpl : deleteUser");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				if (optionalUser.get().isActive()) {
					optionalUser.get().setActive(false);
					userRepository.save(optionalUser.get());
					log.info("UserServiceImpl : deleteUser - " + ConstantMessage.USER + ConstantMessage.INACTIVE
							+ userId);
					return ResponseEntity.status(HttpStatus.OK)
							.body(ConstantMessage.USER + ConstantMessage.INACTIVE + userId);
				} else {
					log.error("UserServiceImpl : deleteUser - " + ConstantMessage.USER + ConstantMessage.INACTIVE_EXIST
							+ userId);
					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(ConstantMessage.USER + ConstantMessage.INACTIVE_EXIST + userId);
				}
			} else {
				log.error("UserServiceImpl : deleteUser - " + ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : deleteUser - " + ConstantMessage.EXCEPTION_FOUND + "delete user :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to change user password by official mail
	 * 
	 * @param officialMail
	 * @param oldPassword
	 * @param newPassword
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> updatePassword(String officialMail, String oldPassword, String newPassword) {
		try {
			log.info("UserServiceImpl : updatePassword");
			Optional<User> optionalUser = isUserPresent(officialMail);
			if (optionalUser.isPresent()) {
				// matches the raw password and encrypt password
				Boolean status = passwordEncoder.matches(oldPassword, optionalUser.get().getPassword());
				if (status == false) {// password doesn't match
					log.error("UserServiceImpl : updatePassword -" + ConstantMessage.OLD_PASSWORD_NOTMATCHED
							+ optionalUser.get().getOfficialMail());

					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(ConstantMessage.OLD_PASSWORD_NOTMATCHED + optionalUser.get().getOfficialMail());
				} else {// password match
					optionalUser.get().setPassword(this.passwordEncoder.encode(newPassword));
					userRepository.save(optionalUser.get());
					log.info("UserServiceImpl : updatePassword - " + ConstantMessage.PASSWORD_CHANGED
							+ optionalUser.get().getOfficialMail());
					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.PASSWORD_CHANGED + officialMail);
				}

			} else {
				log.error("UserServiceImpl : updatePassword - " + ConstantMessage.USER + ConstantMessage.NOTFOUND
						+ officialMail);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + officialMail);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : updatePassword - " + ConstantMessage.EXCEPTION_FOUND + "update password :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to find users by role with pagination
	 * 
	 * @param role
	 * @param pageNo
	 * @param pageSize
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getUsersByRole(String role, int pageNo, int pageSize) {
		try {
			log.info("UserServiceImpl : getUsersByRole");
			// this method convert to pageble format
			List<UserModel> usersList = new ArrayList<UserModel>();
			Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by("userId"));
			// based on roles find list of employees in users table.
			Page<User> users = userRepository.findByRolesContaining(role, paging);
			if (users.isEmpty()) {
				log.info("UserServiceImpl : getUsersByRole - " + ConstantMessage.USER + ConstantMessage.LIST_EMPTY
						+ role);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USER + ConstantMessage.LIST_EMPTY + role);
			}
			for (User user : users) {
				usersList.add(processUserModel(user));
			}
			Map<String, Object> res = new HashMap<>();// Returns map object with userlist, page number and page size
			res.put("Users", usersList);
			res.put("currentPage", users.getNumber());
			res.put("totalItems", users.getTotalElements());
			res.put("totalPages", users.getTotalPages());
			log.info("UserServiceImpl : getUsersByRole - Users are found");
			return ResponseEntity.status(HttpStatus.OK).body(res);
		} catch (Exception e) {
			log.error("UserServiceImpl : getUsersByRole - " + ConstantMessage.EXCEPTION_FOUND + "get users by role :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to upload user profile pic by user id
	 * 
	 * @param userId
	 * @param file
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> uploadProfilePic(int userId, MultipartFile file) {
		try {
			log.info("UserServiceImpl : uploadProfilePic");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				User user = optionalUser.get();
				user.setProfile(Base64.getEncoder().encodeToString(file.getBytes()));
				user.setFileName(file.getOriginalFilename());
				user.setFileType(file.getContentType());
				userRepository.save(user);
				log.info("UserServiceImpl : uploadProfilePic - " + ConstantMessage.PROFILE_PIC_SAVED + userId);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.PROFILE_PIC_SAVED + userId);
			} else {
				log.error("UserServiceImpl : uploadProfilePic - " + ConstantMessage.USER + ConstantMessage.NOTFOUND
						+ userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : uploadProfilePic - " + ConstantMessage.EXCEPTION_FOUND + "upload profile pic :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to fetch user profile pic by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getProfilePic(int userId) {
		try {
			log.info("UserServiceImpl : getProfilePic");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				if (optionalUser.get().getProfile() == null) {
					log.info("UserServiceImpl : getProfilePic - " + ConstantMessage.PROFILE_NOT_FOUND + userId);
					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.PROFILE_NOT_FOUND + userId);
				} else {
					log.info("UserServiceImpl : getProfilePic - Profile picture "+ConstantMessage.RETRIVED + userId);
					return ResponseEntity.status(HttpStatus.OK)
							.body(Base64.getDecoder().decode(optionalUser.get().getProfile()));
				}
			} else {
				log.error("UserServiceImpl : getProfilePic - " + ConstantMessage.USER + ConstantMessage.NOTFOUND
						+ userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : getProfilePic - " + ConstantMessage.EXCEPTION_FOUND + "get profile pic :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to fetch user details by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getUser(int userId) {
		try {
			log.info("UserServiceImpl : getUser");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				log.info("UserServiceImpl : getUser - User " + ConstantMessage.RETRIVED + userId);
				return ResponseEntity.status(HttpStatus.OK).body(processUserModel(optionalUser.get()));
			} else {
				log.error("UserServiceImpl : getUser - " + ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.USER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : getUser - " + ConstantMessage.EXCEPTION_FOUND + "get user :" + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to fetch all users data
	 * 
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getAllUsers() {
		try {
			log.info("UserService : getAllUsers");
			List<UserModel> usersList = new ArrayList<UserModel>();
			List<User> optionalUsers = userRepository.findAll();
			if (!optionalUsers.isEmpty()) {
				for (User user : optionalUsers) {
					usersList.add(processUserModel(user));
				}
				log.info("UserServiceImpl : getAllUsers - Find all users ");
				return ResponseEntity.status(HttpStatus.OK).body(usersList);
			} else {
				log.info("UserServiceImpl : getAllUsers - " + ConstantMessage.USER + ConstantMessage.LIST_EMPTY);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.USER + ConstantMessage.LIST_EMPTY);
			}
		} catch (Exception e) {
			log.error("UserServiceImpl : getAllUsers - " + ConstantMessage.EXCEPTION_FOUND + "get all users :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to user model class properties copy to user class
	 * property
	 * 
	 * @param userModel
	 * @return User
	 */
	public User processUser(UserModel userModel) {
		log.info("UserServiceImpl : processUser - Request user data set to user entity class");
		User user = new User();
		BeanUtils.copyProperties(userModel, user);
		return user;
	}

	/**
	 * This method is used to user model class properties copy to user class
	 * 
	 * @param userModel
	 * @param optional
	 * @return User
	 */
	public User processUserWithProfile(UserModel userModel, Optional<User> optional) {
		log.info("UserServiceImpl : processUserWithProfile - Request user data set to user entity class");
		User user = new User();
		BeanUtils.copyProperties(userModel, user);
		user.setCreatedBy(optional.get().getCreatedBy());
		user.setProfile(optional.get().getProfile());
		user.setFileName(optional.get().getFileName());
		user.setFileType(optional.get().getFileType());
		return user;
	}

	/**
	 * This method is used to user class properties copy to user model class
	 * properties
	 * 
	 * @param user
	 * @return UserModel
	 */
	public UserModel processUserModel(User user) {
		UserModel userModel = new UserModel();
		BeanUtils.copyProperties(user, userModel);
		return userModel;
	}

	/**
	 * This method is used to user is exist or not in user by official mail
	 * 
	 * @param officialMail
	 * @return User
	 */
	public Optional<User> isUserPresent(String officialMail) {
		Optional<User> user = userRepository.findByOfficialMail(officialMail);
		if (user.isPresent())
			return user;
		else
			return user;
	}

	/**
	 * This method is used to check client id exist or not in client table
	 * 
	 * @param clientId
	 * @return boolean
	 */
	public boolean isClientPresent(int clientId) {
		Optional<Client> optionalClient = clientRepository.findById(clientId);
		if (optionalClient.isPresent())
			return true;
		else
			return false;
	}
}
