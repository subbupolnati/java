package com.employee_timesheet.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.employee_timesheet.entity.Client;
import com.employee_timesheet.model.ClientModel;
import com.employee_timesheet.model.ConstantMessage;
import com.employee_timesheet.repository.ClientRepository;
import com.employee_timesheet.service.ClientService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * This ClientServiceImpl class excutes client business logics
 */
@Service
@Data
@Slf4j
public class ClientServiceImpl implements ClientService {

	@Autowired
	private ClientRepository clientRepository;

	/**
	 * This method is used to save client
	 * 
	 * @param clientModel
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> saveClient(ClientModel clientModel) {
		try {
			log.info("ClientServiceImpl : saveClient");
			Optional<Client> optionalClient = clientRepository.findByEmail(clientModel.getEmail());
			if (optionalClient.isPresent()) {
				clientModel.setMessage(ConstantMessage.CLIENT_EXIST);
				log.error("ClientServiceImpl : saveClient -" + ConstantMessage.CLIENT_EXIST + clientModel.getEmail());
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(clientModel);
			} else {
				log.info("ClientServiceImpl : saveClient -" + ConstantMessage.CLIENT + ConstantMessage.SAVE
						+ clientModel.getEmail());
				return ResponseEntity.status(HttpStatus.OK).body(clientRepository.save(processClient(clientModel)));
			}
		} catch (Exception e) {
			log.error("ClientServiceImpl : saveClient -" + ConstantMessage.EXCEPTION_FOUND + "save client :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to get all clients List
	 * 
	 * @return ResponseEntity<?>
	 */
	public ResponseEntity<?> getAllClients() {
		try {
			log.info("ClientServiceImpl : getAllClients");
			List<Client> clientList = clientRepository.findAll();
			if (clientList.isEmpty()) {
				log.info("ClientServiceImpl : getAllClients - " + ConstantMessage.CLIENT + ConstantMessage.LIST_EMPTY);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.CLIENT + ConstantMessage.LIST_EMPTY);
			}
			log.info("ClientServiceImpl : getAllClients - Find all client list");
			return ResponseEntity.status(HttpStatus.OK).body(clientList);
		} catch (Exception e) {
			log.error("ClientServiceImpl : getAllClients -" + ConstantMessage.EXCEPTION_FOUND + "get all clients :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to update client by client id
	 * 
	 * @param clientModel
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> updateClient(ClientModel clientModel) {
		try {
			log.info("ClientServiceImpl : updateClient");
			Optional<Client> optionalClient = clientRepository.findById(clientModel.getClientId());
			if (optionalClient.isPresent()) {
				clientRepository.save(processClient(clientModel));
				log.info("ClientServiceImpl : updateClient - " + ConstantMessage.CLIENT + ConstantMessage.UPDATE
						+ clientModel.getClientId());
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.CLIENT + ConstantMessage.UPDATE + clientModel.getClientId());
			} else {
				log.error("ClientServiceImpl : updateClient - " + ConstantMessage.CLIENT + ConstantMessage.NOTFOUND
						+ clientModel.getClientId());
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.CLIENT + ConstantMessage.NOTFOUND + clientModel.getClientId());
			}
		} catch (Exception e) {
			log.error("ClientServiceImpl : updateClient -" + ConstantMessage.EXCEPTION_FOUND + "update client :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to delete client by client id
	 * 
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> deleteClient(int clientId) {
		try {
			log.info("ClientServiceImpl : deleteClient");
			Optional<Client> optionalClient = clientRepository.findById(clientId);
			if (optionalClient.isPresent()) {
				optionalClient.get().setActive(false);
				clientRepository.save(optionalClient.get());
				log.info("ClientServiceImpl : deleteClient - " + ConstantMessage.CLIENT + ConstantMessage.INACTIVE
						+ clientId);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.CLIENT + ConstantMessage.INACTIVE + clientId);
			} else {
				log.error("ClientServiceImpl : deleteClient - " + ConstantMessage.CLIENT + ConstantMessage.NOTFOUND
						+ clientId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.CLIENT + ConstantMessage.NOTFOUND + clientId);
			}
		} catch (Exception e) {
			log.error("ClientServiceImpl : deleteClient -" + ConstantMessage.EXCEPTION_FOUND + "delete client :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to fetch client by client id
	 * 
	 * @param clientId
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> getClient(int clientId) {
		try {
			log.info("ClientServiceImpl : getClient");
			Optional<Client> optionalClient = clientRepository.findById(clientId);
			if (optionalClient.isPresent()) {
				log.info("ClientServiceImpl : getClient - Client " + ConstantMessage.RETRIVED + clientId);
				return ResponseEntity.status(HttpStatus.OK).body(optionalClient);
			} else {
				log.error("ClientServiceImpl : getClient - " + ConstantMessage.CLIENT + ConstantMessage.NOTFOUND
						+ clientId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.CLIENT + ConstantMessage.NOTFOUND + clientId);
			}
		} catch (Exception e) {
			log.error("ClientServiceImpl : getClient -" + ConstantMessage.EXCEPTION_FOUND + "get client :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to client model class properties copy to client class
	 * properites
	 * 
	 * @param clientModel
	 * @return Client
	 */
	public Client processClient(ClientModel clientModel) {
		Client client = new Client();
		BeanUtils.copyProperties(clientModel, client);
		return client;
	}

}
