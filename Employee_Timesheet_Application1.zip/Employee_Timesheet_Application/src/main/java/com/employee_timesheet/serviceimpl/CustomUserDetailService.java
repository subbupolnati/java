package com.employee_timesheet.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.employee_timesheet.entity.User;
import com.employee_timesheet.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * This CustomUserDetailService class executes username exsits or not and implements UserDetailsService
 *
 */
@Service("CustomUserDetailService")
@Slf4j
public class CustomUserDetailService implements UserDetailsService {
	//this Autowired annotations inject UserRepository dependencies
	@Autowired
	private UserRepository userRepository;
	
	
	/**
	 *This method is used to  get user by officail mail
	 *@param official mail
	 *@return UserDetails
	 */
	@Override
	public UserDetails loadUserByUsername(String officialMail) throws UsernameNotFoundException {
		log.info("CustomUserDetailService:loadUserByUsername-"+officialMail);
		User user=userRepository.findByLoginOfficialMail(officialMail);
		return new CustomUserDetail(user);
	}
}
