package com.employee_timesheet.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.employee_timesheet.entity.User;
import com.employee_timesheet.model.ConstantMessage;
import com.employee_timesheet.model.EmployerModel;
import com.employee_timesheet.model.Response;
import com.employee_timesheet.repository.UserRepository;
import com.employee_timesheet.service.EmployerService;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

/**
 * This EmployerServiceImpl class excutes employer business logics
 */
@Service
@Slf4j
@Data
public class EmployerServiceImpl implements EmployerService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	/**
	 * This method is used to save list of employers
	 * 
	 * @param employerList
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> saveEmployers(List<EmployerModel> employerList) {
		List<EmployerModel> failureEmployerList = new ArrayList<EmployerModel>();
		List<EmployerModel> successEmployerList = new ArrayList<EmployerModel>();
		try {
			log.info("EmployerServiceImpl : saveEmployers");
			for (EmployerModel employer : employerList) {
				Optional<User> optionalEmployer = userRepository.findByOfficialMail(employer.getOfficialMail());
				if (optionalEmployer.isEmpty()) {
					employer.setPassword(passwordEncoder.encode(employer.getPassword()));
					userRepository.save(processUser(employer));
					employer.setMessage(ConstantMessage.EMPLOYER + ConstantMessage.SAVE);
					log.info("EmployerServiceImpl : saveEmployers - "+ConstantMessage.EMPLOYER + ConstantMessage.SAVE
							+ employer.getOfficialMail());
					successEmployerList.add(employer);
				} else {
					log.error("EmployerServiceImpl : saveEmployers - " + ConstantMessage.EMPLOYER
							+ ConstantMessage.EXIST + employer.getOfficialMail());
					employer.setMessage(ConstantMessage.EMPLOYER + ConstantMessage.EXIST);
					failureEmployerList.add(employer);
				}
			}
			Response response = new Response(employerList.size(), successEmployerList.size(),
					failureEmployerList.size(), successEmployerList, failureEmployerList);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			log.error("EmployerServiceImpl : saveEmployers - " + ConstantMessage.EXCEPTION_FOUND + "save employers :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to getting all employers
	 * 
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> getAllEmployers() {
		try {
			log.info("EmployerServiceImpl : getAllEmployers");
			List<User> userList = userRepository.findAll();
			List<EmployerModel> employerList = new ArrayList<EmployerModel>();
			for (User user : userList) {
				if (user.getRoles().equalsIgnoreCase("ROLE_Employer")) {
					employerList.add(processEmployerModel(user));
				}
			}
			log.info("EmployerServiceImpl : getAllEmployers - Find all employers ");
			return ResponseEntity.status(HttpStatus.OK).body(employerList);
		} catch (Exception e) {
			log.error("EmployerServiceImpl : getAllEmployers - " + ConstantMessage.EXCEPTION_FOUND
					+ "get all employers :" + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to update employer
	 * 
	 * @param employerModel
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> updateEmployer(EmployerModel employerModel) {
		try {
			log.info("EmployerServiceImpl : updateEmployer");

			Optional<User> optional = userRepository.findById(employerModel.getUserId());
			if (optional.isPresent()) {
				// This statement check official mail exists or not
				Optional<User> optionalEmployer = userRepository.findByOfficialMail(employerModel.getOfficialMail());
				if (optionalEmployer.isEmpty()
						|| optional.get().getOfficialMail().equals(employerModel.getOfficialMail())) {
					userRepository.save(processUserWithProfile(employerModel,optional));
					log.info("EmployerServiceImpl : updateEmployer - " + ConstantMessage.EMPLOYER
							+ ConstantMessage.UPDATE + employerModel.getUserId());
					return ResponseEntity.status(HttpStatus.OK)
							.body(ConstantMessage.EMPLOYER + ConstantMessage.UPDATE + employerModel.getUserId());
				} else {
					log.error("EmployerServiceImpl : updateEmployer - " + ConstantMessage.EMPLOYER
							+ ConstantMessage.EXIST + employerModel.getOfficialMail());
					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(ConstantMessage.EMPLOYER + ConstantMessage.EXIST + employerModel.getOfficialMail());
				}
			} else {
				log.error("EmployerServiceImpl : updateEmployer -" + ConstantMessage.EMPLOYER + ConstantMessage.NOTFOUND
						+ employerModel.getUserId());
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.EMPLOYER + ConstantMessage.NOTFOUND + employerModel.getUserId());
			}
		} catch (Exception e) {
			log.error("EmployerServiceImpl : updateEmployer - " + ConstantMessage.EXCEPTION_FOUND + "update employer :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to delete employer by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> deleteEmployer(int userId) {
		try {
			log.info("EmployerServiceImpl : deleteEmployer");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				if (optionalUser.get().isActive()) {
					optionalUser.get().setActive(false);
					userRepository.save(optionalUser.get());
					log.info("EmployerServiceImpl : deleteEmployer - " + ConstantMessage.EMPLOYER
							+ ConstantMessage.INACTIVE + userId);
					return ResponseEntity.status(HttpStatus.OK)
							.body(ConstantMessage.EMPLOYER + ConstantMessage.INACTIVE + userId);
				} else {
					log.error("EmployerServiceImpl : deleteEmployer - " + ConstantMessage.EMPLOYER
							+ ConstantMessage.INACTIVE_EXIST + userId);
					return ResponseEntity.status(HttpStatus.BAD_REQUEST)
							.body(ConstantMessage.EMPLOYER + ConstantMessage.INACTIVE_EXIST + userId);
				}
			} else {
				log.error("EmployerServiceImpl : deleteEmployer - " + ConstantMessage.EMPLOYER
						+ ConstantMessage.NOTFOUND + userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.EMPLOYER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("EmployerServiceImpl : deleteEmployer - " + ConstantMessage.EXCEPTION_FOUND + "delete employer :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to get employer by user id
	 * 
	 * @param userId
	 * @return ResponseEntity<?>
	 */
	@Override
	public ResponseEntity<?> getEmployer(int userId) {
		try {
			log.info("EmployerServiceImpl : getEmployer");
			Optional<User> optionalUser = userRepository.findById(userId);
			if (optionalUser.isPresent()) {
				log.info("EmployerServiceImpl : getEmployer - Employer " + ConstantMessage.RETRIVED + userId);
				return ResponseEntity.status(HttpStatus.OK).body(processEmployerModel(optionalUser.get()));
			} else {
				log.error("EmployerServiceImpl : getEmployer - " + ConstantMessage.EMPLOYER + ConstantMessage.NOTFOUND
						+ userId);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.body(ConstantMessage.EMPLOYER + ConstantMessage.NOTFOUND + userId);
			}
		} catch (Exception e) {
			log.error("EmployerServiceImpl : getEmployer - " + ConstantMessage.EXCEPTION_FOUND + "get employer :"
					+ e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

	/**
	 * This method is used to user class properties copy to employer model class
	 * properties
	 * 
	 * @param user
	 * @return EmployerModel
	 */
	private EmployerModel processEmployerModel(User user) {
		EmployerModel employerModel = new EmployerModel();
		BeanUtils.copyProperties(user, employerModel);
		return employerModel;
	}

	/**
	 * This method is used to employer model class properties copy to user model
	 * class properties
	 * 
	 * @param employerModel
	 * @return User
	 */
	public User processUser(EmployerModel employerModel) {
		User user = new User();
		BeanUtils.copyProperties(employerModel, user);
		return user;
	}
	/**
	 * This method is used to employer model class properties copy to user model
	 * class properties
	 * 
	 * @param employerModel,optional
	 * @return User
	 */
	public User processUserWithProfile(EmployerModel employerModel,Optional<User> optional) {
		User user = new User();
		BeanUtils.copyProperties(employerModel, user);
		user.setCreatedBy(optional.get().getCreatedBy());
		user.setPassword(optional.get().getPassword());
		user.setProfile(optional.get().getProfile());
		user.setFileName(optional.get().getFileName());
		user.setFileType(optional.get().getFileType());
		return user;
	}
}
