package com.employee_timesheet.serviceimpl;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.employee_timesheet.entity.User;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
/**
 * This CustomUserDetail class executes save roles and authorites
 *
 */
@Configuration
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CustomUserDetail implements UserDetails {
	private static final long serialVersionUID = 1L;
	private User user;
	

	/**
	 *This method is used to getAuthorities and add GrantedAuthority in hashSet
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		log.info("CustomUserDetail :getAuthorities ");
		HashSet<GrantedAuthority> hs=new HashSet<GrantedAuthority>();
		hs.add(new SimpleGrantedAuthority(this.user.getRoles()));
		return hs;
	}

	/**
	 *This method is used to get password
	 *@return String
	 */
	@Override
	public String getPassword() {
		log.info("CustomUserDetail :getPassword ");
		return this.user.getPassword();
	}
	/**
	 *This method is used to get username
	 *@return String
	 */
	@Override
	public String getUsername() {
		log.info("CustomUserDetail :getUsername");
		return this.user.getOfficialMail();
	}
	/**
	 *This method is used to account expired or not
	 *@return boolean
	 */
	@Override
	public boolean isAccountNonExpired() {
		log.info("CustomUserDetail :isAccountNonExpired");
		return true;
	}
	/**
	 *This method is used to account locked or not
	 *@return boolean
	 */
	@Override
	public boolean isAccountNonLocked() {
		log.info("CustomUserDetail :isAccountNonLocked ");
		return true;
	}
	/**
	 *This method is used to credentials expired or not
	 *@return boolean
	 */
	@Override
	public boolean isCredentialsNonExpired() {
		log.info("CustomUserDetail :isCredentialsNonExpired ");
		return true;
	}
	/**
	 *This method is used to enable or not
	 *@return boolean
	 */
	@Override
	public boolean isEnabled() {
		log.info("CustomUserDetail :isEnabled ");
		return true;
	}

}
