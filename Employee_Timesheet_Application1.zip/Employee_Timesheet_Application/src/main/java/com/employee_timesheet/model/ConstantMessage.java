package com.employee_timesheet.model;

import org.springframework.context.annotation.Configuration;

import lombok.Data;

/**
 * This constant message class is used to execute constant messages
 *
 */
@Data
@Configuration
public class ConstantMessage {

	public static final String USER = "User ";
	public static final String CLIENT = "Client ";
	public static final String EMPLOYER = "Employer ";
	public static final String SAVE = " successfully saved :";
	public static final String NOTFOUND = "not found :";
	public static final String UPDATE = "updated successfully :";
	public static final String INACTIVE = "successfully inactivted :";
	public static final String INACTIVE_EXIST = "already inactivted :";
	public static final String EXCEPTION_FOUND = "Exception occurred while ";
	public static final String LIST_EMPTY = " List is empty ";
	public static final String OLD_PASSWORD_NOTMATCHED = "User old password doesnot match :";
	public static final String PASSWORD_CHANGED = "User password successfully changed :";
	public static final String PROFILE_PIC_SAVED = "User profile pic successfully uploaded :";
	public static final String PROFILE_PIC_UNSAVED = "User profile pic too large please upload below :";
	public static final String PROFILE_NOT_FOUND = "User profile pic not found please upload profic pic :";
	public static final String CLIENT_EXIST = "This email already exists to another client :";
	public static final String EXIST = "already exist with this official mail :";
	public static final String FIND_ALL_USERS = "Find all users details ";
	public static final String RETRIVED="successfully retrived :";
}
