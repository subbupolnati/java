package com.employee_timesheet.model;

import lombok.AllArgsConstructor;


/**
 * This bank model class is used to stores data
 *
 */
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BankModel {
	
	private int bankId;
	private String bankName;
	private long accountNumber;
	private long routingNumber;
}
