package com.employee_timesheet.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * This employer model class is used to stores data
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployerModel {

	private int userId;
	private boolean active;
	private String address;
	private String bankDetails;
	private String contactNo;
	private String createdBy;
	private LocalDate createdTime;
	private String designation;
	private String dob;
	private String firstName;
	private String gender;
	private LocalDate joiningDate;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;
	private String lastName;
	private String officialMail;
	private String password;
	private String roles;
	private String userType;
	private String message;
	
}
