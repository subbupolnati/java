package com.employee_timesheet.model;

import lombok.Data;

@Data
public class UserLogin {

	private String userName;
	private String password;
	private String role;
}
