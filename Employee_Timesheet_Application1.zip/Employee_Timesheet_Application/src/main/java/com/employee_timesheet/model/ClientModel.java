package com.employee_timesheet.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * This client model class is used to stores data
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientModel {
	private int clientId;
	private boolean active;
	private String address;
	private String clientName;
	private String contactNo;
	private String createdBy;
	private LocalDate createdDate;
	private String email;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;
	private String message;
}
