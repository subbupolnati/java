package com.employee_timesheet.model;

import java.util.List;

import org.springframework.context.annotation.Configuration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This Response class return response
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Configuration
public class Response {
	private int totalUsersCount;
	private int successUsersCount;
	private int failureUsersCount;
	private List<?> successList;
	private List<?> failureList;
}
