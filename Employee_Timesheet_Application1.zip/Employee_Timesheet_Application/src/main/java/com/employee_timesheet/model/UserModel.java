package com.employee_timesheet.model;

import java.time.LocalDate;

import com.employee_timesheet.entity.Bank;
import com.employee_timesheet.entity.Client;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This user model class is used to stores user data
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserModel {
	private int userId;
	private boolean active;
	private String address;
	private Bank bankDetails;
	private double compensation;
	private String contactNo;
	private String createdBy;
	private LocalDate createdTime;
	private String designation;
	private String dob;
	private String employerMail;
	private String firstName;
	private boolean firstTime;
	private String gender;
	private LocalDate joiningDate;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;
	private String lastName;
	private String machineAssetno;
	private String managerMail;
	private String officialMail;
	private String password;
	private String personalMail;
	private String roles;
	private String userType;
	private Client client;
	private String message;
}