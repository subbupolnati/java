package com.employee_timesheet.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This model class is used to encapsulates client data
 *
 */
@Entity
@Table(name="client")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class Client {

	@Id//this annotation used to generate primary key
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int clientId;
	private boolean active;
	private String address;
	private String clientName;
	private String contactNo;
	@CreatedBy
	private String createdBy;
	@Column(name = "created_date", nullable = false, updatable = false)
    @CreatedDate
	private LocalDate createdDate;
	private String email;
	@LastModifiedBy
	private String lastModifiedBy;
	@LastModifiedDate
	@Column(name = "last_modified_date", nullable = false, updatable = false)
	private LocalDate lastModifiedDate;
}
