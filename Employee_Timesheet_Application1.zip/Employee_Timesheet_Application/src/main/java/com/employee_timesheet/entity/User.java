package com.employee_timesheet.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This user entity class is used to encapsulates user data.
 */
@Entity // This Annotations class like Entity model class
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class User {

	@Id // this annotation used to generate primary key
	// this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	private boolean active;
	private String address;
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "bank_id")
	private Bank bankDetails;
	private double compensation;
	private String contactNo;
	@CreatedBy
	private String createdBy;
	@Column(name = "created_date", nullable = false, updatable = false)
    @CreatedDate
	private LocalDate createdTime;
	private String designation;
	private String dob;
	private String employerMail;
	private LocalDate endDate;
	private String fileName;
	private String fileType;
	private String firstName;
	private boolean firstTime;
	private String gender;
	private LocalDate joiningDate;
	@LastModifiedBy
	private String lastModifiedBy;
	@LastModifiedDate
	@Column(name = "last_modified_date", nullable = false, updatable = false)
	private LocalDate lastModifiedDate;
	private String lastName;
	private String machineAssetno;
	private String managerMail;
	@Column(unique = true)
	private String officialMail;
	private String password;
	private String personalMail;
	@Lob
	@Column(name = "profile", length = Integer.MAX_VALUE, nullable = true)
	private String profile;
	private String roles;
	private String userType;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "client_id")
	private Client client;
}
