package com.employee_timesheet.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.employee_timesheet.filter.JwtAuthenticationFilter;
import com.employee_timesheet.serviceimpl.CustomUserDetailService;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * This UserSecurityConfig class executes security authentications
 *
 */
@EnableWebSecurity
@Configuration
@Setter
@Getter
@Slf4j
public class UserSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private CustomUserDetailService customUserDetailService;
	@Autowired
	private JwtAuthenticationFilter jwtFilter;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		log.info("UserSecurityConfig :configure");
		http.csrf().disable().authorizeHttpRequests().antMatchers("/v1/timesheet/save/admin").permitAll()
				.antMatchers("/v1/timesheet/save/users").hasAnyRole("Admin", "HR")
				.antMatchers("/v1/timesheet/chanagepassowrd/**").hasAnyRole("HR", "Employee")
				.antMatchers("/v1/timesheet/update/user/**").hasAnyRole("HR", "Employee")
				.antMatchers("/v1/timesheet/uploadprofile/**").hasAnyRole("HR", "Employee")
				.antMatchers("/v1/timesheet/delete/user/**").hasRole("HR").antMatchers("/v1/timesheet/fetchuser/**")
				.hasRole("HR").antMatchers("/v1/timesheet/fetchprofilepic/**").hasRole("HR")
				.antMatchers("/v1/timesheet/get/users").hasAnyRole("HR").antMatchers("/v1/timesheet/client/**")
				.hasAnyRole("HR").antMatchers("/v1/timesheet/employer/**").hasAnyRole("HR")
				.antMatchers("/v1/timesheet/login").permitAll().anyRequest().authenticated().and().sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		log.info("UserSecurityConfig :configure");
		auth.userDetailsService(customUserDetailService).passwordEncoder(passwordEncoder());
	}
	@Override
	public void configure(WebSecurity web) throws Exception {
	    web.ignoring().antMatchers(
	        "/v2/api-docs", 
	        "/swagger-resources/configuration/ui",     
	        "/swagger-resources", 
	        "/swagger-resources/configuration/security", 
	        "/swagger-ui.html",     
	        "/webjars/**");
	}
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		log.info("UserSecurityConfig :BCryptPasswordEncoder");
		return new BCryptPasswordEncoder();
	}

	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		log.info("UserSecurityConfig :authenticationManagerBean");
		return super.authenticationManager();
	}
}
