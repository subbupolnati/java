package com.employee_timesheet.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.employee_timesheet.filter.JwtAuthenticationFilter;
import com.employee_timesheet.service.CustomUserDetailService;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@EnableWebSecurity
@Configuration
@Setter
@Getter
@Slf4j
public class UserSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private CustomUserDetailService customUserDetailService;
	@Autowired
	private JwtAuthenticationFilter jwtFilter;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		log.info("UserSecurityConfig :configure-");
		http
		.csrf().disable()
		.cors()
		.disable()
        .authorizeHttpRequests()
        .antMatchers("/v1/timesheet/user").permitAll()
		.antMatchers("/login").permitAll()
		.antMatchers("/v1/timesheet/chanagepassowrd/**").hasAnyRole("HR","Employee")
		.antMatchers("/v1/timesheet/updateuser/**").hasAnyRole("HR","Employee")
		.antMatchers("/v1/timesheet/uploadprofile/**").hasAnyRole("HR","Employee")
		.antMatchers("/v1/timesheet/deleteuser/**").hasRole("HR")
		.antMatchers("/v1/timesheet/fetchuser/**").hasRole("HR")
		.antMatchers("/v1/timesheet/fetchprofilepic/**").hasRole("HR")
		.antMatchers("/v1/timesheet/users").hasAnyRole("HR")
		.antMatchers("/v1/timesheet/client/**").hasAnyRole("HR")
		.antMatchers("/v1/timesheet/client").hasAnyRole("HR")
		.antMatchers("/v1/timesheet/clients").hasAnyRole("HR")
		.antMatchers("/v1/timesheet/holiday/**").hasAnyRole("HR")
		.antMatchers("/v1/timesheet/holidays").hasAnyRole("HR")
		.anyRequest()
		.authenticated()
		.and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		http.addFilterBefore(jwtFilter,UsernamePasswordAuthenticationFilter.class);
	}
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		log.info("UserSecurityConfig :configure-");
		auth.userDetailsService(customUserDetailService).passwordEncoder(passwordEncoder());
	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		log.info("UserSecurityConfig :BCryptPasswordEncoder-");
		return new BCryptPasswordEncoder();
	}
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception
	{
		log.info("UserSecurityConfig :authenticationManagerBean-");
		return super.authenticationManager();
	}
}
