package com.employee_timesheet.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.employee_timesheet.model.RequestUser;
import com.employee_timesheet.model.ResetPassword;
import com.employee_timesheet.model.User;
import com.employee_timesheet.service.UserService;
import lombok.extern.slf4j.Slf4j;

//This class acts like User Controller checking urls
@RestController
@RequestMapping("/v1/timesheet")
@Slf4j

public class UserController {
	// this Autowired annotations inject UserService dependencies
	@Autowired
	private UserService userService;

	// this url and method store user details in database based on restapi data
	@PostMapping("/user")
	public ResponseEntity<?> saveUsers(@RequestBody List<RequestUser> usersList) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.insertUser(usersList);
		long endTime = System.currentTimeMillis();
		log.info("UserController:saveUsers- Time taken for executing save users " + (endTime - startTime) + " ms");
		return responseEntity;
	}

	// this url and method getting all user details in database based n restapi data
	@GetMapping("/users")
	public ResponseEntity<?> getAllUsers() {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getAllUsers();
		long endTime = System.currentTimeMillis();
		log.info("UserController : getAllUsers -Time taken for executing getting All Users " + (endTime - startTime)
				+ " ms");
		return responseEntity;
	}

	// In this url and method getting particular user based on official mail
	@GetMapping("/user/{officialMail}")
	public ResponseEntity<?> getUserByOfficialMail(@PathVariable("officialMail") String officialMail) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getUserByOfficialMail(officialMail);
		long endTime = System.currentTimeMillis();
		log.info("UserController : getUserByOfficialMail -Time taken for executing getting user "
				+ (endTime - startTime) + " ms");
		return responseEntity;
	}

	// In this url and method update particular user based on userid
	@PutMapping("/updateuser")
	public ResponseEntity<?> updateUserByUserId(@RequestBody User user) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.updateUser(user);
		long endTime = System.currentTimeMillis();
		log.info("UserController : updateUserByUserId-Time taken for executing update user " + (endTime - startTime)
				+ "ms");
		return responseEntity;
	}

	// In this url and method delete particular user based on userid
	@DeleteMapping("/deleteuser/")
	public ResponseEntity<?> deleteUserByOfficialMail(@RequestParam("officialMail") String officialMail) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.deleteUser(officialMail);
		long endTime = System.currentTimeMillis();
		log.info("UserController : deleteUserByOfficialMail-Time taken for executing delete user"
				+ (endTime - startTime) + "ms");
		return responseEntity;
	}

	// In this url change password based on official mailId
	@PutMapping("/chanagepassowrd/{officialMail}")
	public ResponseEntity<?> changePassword(@PathVariable("officialMail") String officialMail,
			@RequestBody ResetPassword resetPassword) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.changePasswordByMail(officialMail, resetPassword);
		long endTime = System.currentTimeMillis();
		log.info("UserController :changePassword -Time taken for executing changePassword " +(endTime - startTime)
				+ "ms ");
		return responseEntity;
	}

	// In This url fetching employees using pagination and size
	@GetMapping("/fetchuser/{role}/{pageNo}/{pageSize}")
	public ResponseEntity<?> getPaginatedEmployees(@PathVariable("role") String role,
			@PathVariable("pageNo") int pageNo, @PathVariable("pageSize") int pageSize) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.findAllEmployeesByRole(role, pageNo, pageSize);
		long endTime = System.currentTimeMillis();
		log.info("UserController :getPaginatedEmployees- Time taken for executing gettingAllEmployeesWithPagination "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	// In This url upload user profile pic using userId
	@PostMapping(value = "/uploadprofile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> uploadProfilePicByUserId(@RequestParam("userId") int userId,
			@RequestParam("profile") MultipartFile file) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.uploadProfilePic(userId, file);
		long endTime = System.currentTimeMillis();
		log.info("UserController : uploadProfilePicByUserId -Time taken for executing uploadProfilePic "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	// In This url fetch user profile pic using userId
	@GetMapping(value = "/fetchprofilepic/{userId}", produces = MediaType.IMAGE_JPEG_VALUE)
	public ResponseEntity<?> fetchProfilePicByUserId(@PathVariable("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.fetchProfilePic(userId);
		long endTime = System.currentTimeMillis();
		log.info("UserController :fetchProfilePicByUserId -Time taken for executing fetchProfilePic "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}

	// In This url fetch user profile pic using userId
	@GetMapping(value = "/fetchuser/{userId}")
	public ResponseEntity<?> fetchEmployeeByUserId(@PathVariable("userId") int userId) {
		long startTime = System.currentTimeMillis();
		ResponseEntity<?> responseEntity = userService.getEmployeeByUserId(userId);
		long endTime = System.currentTimeMillis();
		log.info("UserController : fetchEmployeeByUserId -Time taken for executing fetchEmployee "
				+ (endTime - startTime) + "ms ");
		return responseEntity;
	}
}
