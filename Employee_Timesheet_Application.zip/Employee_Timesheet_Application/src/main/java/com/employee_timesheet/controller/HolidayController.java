package com.employee_timesheet.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.employee_timesheet.model.Holiday;
import com.employee_timesheet.service.HolidayService;
@RestController
@RequestMapping("/v1/timesheet")
public class HolidayController {

	@Autowired
	private HolidayService holidayService;
	//In This url and Method insert new Holiday. 
	@PostMapping("/holiday")
	public ResponseEntity<Holiday> insertHoliday(@RequestBody Holiday holiday) {
		Holiday h=holidayService.insertHoliday(holiday);
		URI location=ServletUriComponentsBuilder.fromCurrentRequest().path("/{holidayId}").buildAndExpand(h.getHolidayId()).toUri();
		return ResponseEntity.created(location).build();
	}
	//In This Url/method getting all Holidays List
	@GetMapping("/holidays")
	public List<Holiday> fetchAllHolidays(){
		return holidayService.getAllHolidays();
	}
	//In This Url/method fetching particular holiday based on reason
	@GetMapping("/holiday/{reason}")
	public Holiday fetchHolidayByReason(@PathVariable("reason")String reason){
		return holidayService.getHolidayByReason(reason);
	}
	//In This Url/method update particular Holiday based on holidayId
	@PutMapping("/holiday/{holidayId}")
	public Holiday modifyHolidayById(@PathVariable("holidayId")int holidayId,@RequestBody Holiday holiday) {
		return holidayService.updateHoliday(holiday, holidayId);
	}
	
	//In This Url/method delete particular Holiday based on HolidayId
	@DeleteMapping("/holiday/{holidayId}")
	public String deleteHolidayById(@PathVariable("holidayId")int holidayId) {
		holidayService.deleteHoliday(holidayId);
		return "successfully deleted"+holidayId;
	}
	
}
