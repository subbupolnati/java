package com.employee_timesheet.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.employee_timesheet.helper.JwtTokenUtil;
import com.employee_timesheet.model.JwtResponse;
import com.employee_timesheet.model.UserLogin;
import com.employee_timesheet.service.CustomUserDetailService;

import lombok.Data;
//This class acts like Controller checking urls
@Controller
@Data
public class JWTController {

	@Autowired //this Autowired annotations inject CustomUserDetailService dependencies
	private CustomUserDetailService customUserDetailService;
	//this Autowired annotations inject jwttokenutil dependencies
	@Autowired
	private JwtTokenUtil jwttokenutil;
	//this Autowired annotations inject AuthenticationManage dependencies
	@Autowired 
	private AuthenticationManager mgr;
	
	//in this url and method is using login user and authenticate user name and password and generate jwt token
	@PostMapping("/login")
	public ResponseEntity<?> generateToken(@RequestBody UserLogin user){
		try {
			//this authenticate method validate username and password based on user data  
			this.mgr.authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(),user.getPassword()));
			
		}catch(UsernameNotFoundException ue){
			throw new UsernameNotFoundException("user not found");
		}	
		//this statement validate user name  based on user data and return user details
		UserDetails userDetails=this.customUserDetailService.loadUserByUsername(user.getUsername());
		//this statement generate token based on user details
		String token=this.jwttokenutil.generateToken(userDetails);
		System.out.println(token);
		return ResponseEntity.ok(new JwtResponse(token));
	}
}
	
