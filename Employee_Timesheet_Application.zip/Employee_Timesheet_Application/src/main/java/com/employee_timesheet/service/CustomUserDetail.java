package com.employee_timesheet.service;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.employee_timesheet.model.User;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Configuration
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CustomUserDetail implements UserDetails {
	private static final long serialVersionUID = 1L;
	private User users;
	

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		log.info("CustomUserDetail :getAuthorities -");
		HashSet<GrantedAuthority> hs=new HashSet<GrantedAuthority>();
		hs.add(new SimpleGrantedAuthority(this.users.getRoles()));
		return hs;
	}

	@Override
	public String getPassword() {
		log.info("CustomUserDetail :getPassword -");
		return this.users.getPassword();
	}

	@Override
	public String getUsername() {
		log.info("CustomUserDetail :getUsername -");
		return this.users.getOfficialMail();
	}

	@Override
	public boolean isAccountNonExpired() {
		log.info("CustomUserDetail :isAccountNonExpired -");
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		log.info("CustomUserDetail :isAccountNonLocked -");
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		log.info("CustomUserDetail :isCredentialsNonExpired -");
		return true;
	}

	@Override
	public boolean isEnabled() {
		log.info("CustomUserDetail :isEnabled -");
		return true;
	}

}
