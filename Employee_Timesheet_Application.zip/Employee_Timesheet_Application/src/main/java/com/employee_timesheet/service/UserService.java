package com.employee_timesheet.service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.employee_timesheet.model.ConstantMessage;
import com.employee_timesheet.model.RequestUser;
import com.employee_timesheet.model.ResetPassword;
import com.employee_timesheet.model.Response;
import com.employee_timesheet.model.User;
import com.employee_timesheet.repository.UserRepository;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Service
@Data
@Slf4j
public class UserService {
	// This Autowired annotations inject UserRepository dependencies
	@Autowired
	private UserRepository userRepository;
	// This Autowired annotations inject BCryptPasswordEncoder dependencies using
	// password encrypt
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	// This method is used to save List of users data 
	public ResponseEntity<?> insertUser(List<RequestUser> usersList) {
		List<RequestUser> failureUserList = new ArrayList<RequestUser>();
		List<RequestUser> successUserList = new ArrayList<RequestUser>();
		try {
			log.info("UserService: insertUser");
			for (RequestUser userElement : usersList) {
				User user = userRepository.findByOfficialMail(userElement.getOfficialMail());
				if (user == null) {
					userElement.setPassword(this.passwordEncoder.encode(userElement.getPassword()));
					User userData = this.setSuccessUserListInUsers(userElement);
					userRepository.save(userData);
					userElement.setMessage(ConstantMessage.USER_SAVE);
					log.info("UserService: insertUser - Users successfully saved");
					successUserList.add(userElement);
				} else {
					log.error("UserService: insertUser - Users official mail already exists" + userElement.getUserId());
					RequestUser failureUser = this.setUserListInRequestUser(user);
					failureUserList.add(failureUser);
				}
			}
			Response response=new Response();
			response.setFailureUsersCount(failureUserList.size());
			response.setFailureUsersList(failureUserList);
			response.setSuccessUsersCount(successUserList.size());
			response.setSuccessUsersList(successUserList);
			
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			log.error("UserService: insertUser -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to getting all users data
	public ResponseEntity<?> getAllUsers() {
		try {
			log.info("UserService: getAllUsers");
			List<User> users = userRepository.findAll();
			if (!users.isEmpty()) {
				log.info("UserService: getAllUsers- Find all users ");
				return ResponseEntity.status(HttpStatus.OK).body(users);
			} else {
				log.error("UserService: getAllUsers-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.USERS_NOTFOUND);
			}
		} catch (Exception e) {
			log.error("UserService : getAllusers -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to getting user details based on userOfficial mail
	public ResponseEntity<?> getUserByOfficialMail(String officialMail) {
		try {
			log.info("UserService: getUserByOfficialMail");
			User user = userRepository.findByOfficialMail(officialMail);
			// if user instance not null execute if block other wise it returns comment
			// null;
			if (user == null) {
				log.error("UserService: getUserByOfficialMail-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " Official mail :" + officialMail);
			}
			log.info("UserService: getUserByOfficialMail - User found " + officialMail);
			return ResponseEntity.status(HttpStatus.OK).body(user);
		} catch (Exception e) {
			log.error("UserService :getUserByOfficialMail -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to update user data
	public ResponseEntity<?> updateUser(User user) {
		try {
			log.info("UserService: updateUser");
			Optional<User> optional = userRepository.findById(user.getUserId());
			if (optional.isPresent()) {
				User checkUser = userRepository.findByOfficialMail(user.getOfficialMail());// This statement check
																							// official mail are exists
																							// or not
				if (checkUser == null || optional.get().getOfficialMail().equals(user.getOfficialMail())) {
					userRepository.save(user);
					log.info("UserService: updateUser - User updated successfully :" + user.getUserId());
					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.UPDATE_USERS);
				} else {
					log.error(
							"UserService: updateUser - User updated unsuccessfully because official mail already exists :"
									+ user.getUserId());
					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.USER_EXIST + " " + checkUser.getUserId());
				}
			} else {
				log.error("UserService: updateUser -" + " Userid is " + user.getUserId() + " "
						+ ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " userId : " + user.getUserId());
			}
		} catch (Exception e) {
			log.error("UserService :updateUser -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to delete user data based on official mail id
	public ResponseEntity<?> deleteUser(String officialMail) {
		try {
			log.info("UserService: deleteUser");
			User user = userRepository.findByOfficialMail(officialMail);
			if (user != null) {
				user.setActive(false);
				log.info("UserService : deleteUser -Successfully inactive user" + officialMail);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.INACTIVE_USER);
			} else {
				log.error("UserService: deleteUser -" + "Officialmail is " + officialMail + " "
						+ ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " OfficialMail : " + officialMail);
			}
		} catch (Exception e) {
			log.error("UserService :deleteUser -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// IThis method is used to change password based on official mail id
	public ResponseEntity<?> changePasswordByMail(String officialMail, ResetPassword resetPassword) {
		try {
			log.info("UserService: changePasswordByMail");
			User user = userRepository.findByOfficialMail(officialMail);
			if (user != null) {
				// matches the raw password and encrypt password
				Boolean status = passwordEncoder.matches(resetPassword.getOldPassword(), user.getPassword());
				if (status == false) {// password doesn't match
					log.error("UserService : changePasswordByMail -Official mail is" + officialMail + " "
							+ ConstantMessage.OLD_PASSWORD_NOTMATCHED);

					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.OLD_PASSWORD_NOTMATCHED);
				} else {// password match
					user.setPassword(this.passwordEncoder.encode(resetPassword.getNewPassword()));
					userRepository.save(user);
					log.info("UserService : changePasswordByMail -Official mail is" + officialMail + " "
							+ ConstantMessage.PASSWORD_CHANGED);
					return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.PASSWORD_CHANGED);
				}
				
			} else {
				log.error("UserService : changePasswordByMail -Official mail is" + officialMail + " "
						+ ConstantMessage.USERS_NOTFOUND);
				;
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " Officialmail : " + officialMail);
			}
		} catch (Exception e) {
			log.error("UserService :changePasswordByMail -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to find all employees based on roles with pagination
	public ResponseEntity<?> findAllEmployeesByRole(String role, int pageNo, int pageSize) {
		try {
			log.info("UserService: findAllEmployeesByRole");
			List<User> findEmpList = new ArrayList<User>();
			Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by("userId"));// this method convert to pageble
																					// format
			Page<User> result = userRepository.findByRolesContaining(role, paging);// based on roles find list of
																					// employees in users table.
			findEmpList = result.toList();// convert to list
			if (findEmpList.isEmpty()) {
				log.info("UserService :findAllEmployeesByRole-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK).body(ConstantMessage.USERS_NOTFOUND + " Roles : " + role);
			}
			Map<String, Object> res = new HashMap<>();// response map object return list withpage number and size
			res.put("Employees", findEmpList);
			res.put("currentPage", result.getNumber());
			res.put("totalItems", result.getTotalElements());
			res.put("totalPages", result.getTotalPages());
			log.info("UserService :findAllEmployeesByRole-Users found");
			return ResponseEntity.status(HttpStatus.OK).body(res);
		} catch (Exception e) {
			log.error("UserService :findAllEmployeesByRole -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to upload user profile pic based on userId
	public ResponseEntity<?> uploadProfilePic(int userId, MultipartFile file) {
		try {
			log.info("UserService: uploadProfilePic");
			Optional<User> userCheck = userRepository.findById(userId);
			User user = null;
			if (userCheck.isPresent()) {
				byte[] byteObjects = file.getBytes();// convertToBytes(file);
				String encodedProfile = Base64.getEncoder().encodeToString(byteObjects);
				user = userCheck.get();
				user.setProfile(encodedProfile);
				user.setFileName(file.getOriginalFilename());
				user.setFileType(file.getContentType());
				userRepository.save(user);
				log.info("UserService :uploadProfilePic- Successfully upload user profile" + userId);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.PROFILE_PIC_SAVED + " fileName is" + file.getOriginalFilename());
			} else {
				log.error("UserService :uploadProfilePic-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " UserId : " + userId);
			}
		} catch (Exception e) {
			log.error("UserService :uploadProfilePic -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to  fetch user profile pic based on userId
	public ResponseEntity<?> fetchProfilePic(int userId) {
		try {
			log.info("UserService: fetchProfilePic");
			Optional<User> userCheck = userRepository.findById(userId);
			if (userCheck.isPresent()) {
				log.info("UserService :fetchProfilePic-" + userId);
				return ResponseEntity.status(HttpStatus.OK)
						.body(Base64.getDecoder().decode(userCheck.get().getProfile()));
			} else {
				log.error("UserService :fetchProfilePic-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " UserId : " + userId);
			}
		} catch (Exception e) {
			log.error("UserService :fetchProfilePic -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to fetch user details based on userId
	public ResponseEntity<?> getEmployeeByUserId(int userId) {
		try {
			log.info("UserService: getEmployeeByUserId");
			Optional<User> userCheck = userRepository.findById(userId);
			User user = null;
			if (userCheck.isPresent()) {
				user = userCheck.get();
				log.info("UserService :getEmployeeByUserId-" + userId);
				return ResponseEntity.status(HttpStatus.OK).body(user);
			} else {
				log.error("UserService :getEmployeeByUserId-" + ConstantMessage.USERS_NOTFOUND);
				return ResponseEntity.status(HttpStatus.OK)
						.body(ConstantMessage.USERS_NOTFOUND + " UserId : " + userId);
			}
		} catch (Exception e) {
			log.error("UserService :getEmployeeByUserId -" + e.getMessage());
			return ResponseEntity.internalServerError().body(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// This method is used to setSuccessUserList into UsersEntity Model Class
	public User setSuccessUserListInUsers(RequestUser requestUser) {
		log.info("UserService:setSuccessUserListInUsers-Request user data set to users entity class");
		User user = new User(requestUser.getUserId(), true, requestUser.getAddress(), requestUser.getBankDetails(),
				requestUser.getCompensation(), requestUser.getContactNo(), requestUser.getCreatedBy(), null,
				requestUser.getDesignation(), requestUser.getDob(), requestUser.getEmployerMail(), null, null, null,
				requestUser.getFirstName(), false, requestUser.getGender(), requestUser.getJoiningDate(),
				requestUser.getLastModifiedBy(), requestUser.getLastModifiedDate(), requestUser.getLastName(),
				requestUser.getMachineAssetno(), requestUser.getManagerMail(), requestUser.getOfficialMail(),
				requestUser.getPassword(), requestUser.getPersonalMail(), null, requestUser.getRoles(),
				requestUser.getUserType(), null);
		return user;
	}

	// This method is used to setUserList into UsersEntity Model Class
	public RequestUser setUserListInRequestUser(User user) {
		log.info("UserService:setUserListInRequestUser-User entity data set to requestuser class");
		RequestUser requestUser = new RequestUser(user.getUserId(), true, user.getAddress(), user.getBankDetails(),
				user.getCompensation(), user.getContactNo(), user.getCreatedBy(), user.getDesignation(), user.getDob(),
				user.getEmployerMail(), user.getFirstName(), false, user.getGender(), user.getJoiningDate(),
				user.getLastModifiedBy(), user.getLastModifiedDate(), user.getLastName(), user.getMachineAssetno(),
				user.getManagerMail(), user.getOfficialMail(), user.getPassword(), user.getPersonalMail(),
				user.getRoles(), user.getUserType(), null, ConstantMessage.USER_EXIST);
		return requestUser;
	}
}
