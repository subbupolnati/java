package com.employee_timesheet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.employee_timesheet.model.User;
import com.employee_timesheet.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;


//this class is used to service write n database business logics
@Service("CustomUserDetailService")
@Slf4j
public class CustomUserDetailService implements UserDetailsService {
	//this Autowired annotations inject UserRepository dependencies
	@Autowired
	private UserRepository userRepository;
	
	
	//This method override loadbyusername method in userDetailsService class 
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		log.info("CustomUserDetailService:loadUserByUsername-"+username);
		User user=userRepository.findByOfficialMail(username);
		return new CustomUserDetail(user);
	}
	
}
