package com.employee_timesheet.model;

import lombok.Data;

@Data
public class ResetPassword {
	private String oldPassword;
	private String newPassword;
}
