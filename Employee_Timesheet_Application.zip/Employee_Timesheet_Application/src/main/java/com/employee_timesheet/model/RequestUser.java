package com.employee_timesheet.model;

import java.time.LocalDate;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestUser {
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_generator")
	@SequenceGenerator(name="user_generator", sequenceName = "user_seq", allocationSize=1)
	private int userId;
	private boolean active;
	private String address;
	private String bankDetails;
	private double compensation;
	private String contactNo;
	private String createdBy;
	private String designation;
	private String dob;
	private String employerMail;
	private String firstName;
	private boolean firstTime;
	private String gender;
	private LocalDate joiningDate;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;
	private String lastName;
	private String machineAssetno;
	private String managerMail;
	private String officialMail;
	private String password;
	private String personalMail;
	private String roles;
	private String userType;
	private Client client;
	private String message;
}
