package com.employee_timesheet.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="otp")
@Data
public class Otp {
	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "otp_generator")
	@SequenceGenerator(name="otp_generator", sequenceName = "otp_seq", allocationSize=1)
	private int id;
	private String email;
	private String otp;
}
