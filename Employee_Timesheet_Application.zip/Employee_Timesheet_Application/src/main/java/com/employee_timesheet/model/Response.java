package com.employee_timesheet.model;

import java.util.List;

import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@Configuration
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Response {
	private String description;
	private int failureUsersCount;
	private int successUsersCount;
	private List<RequestUser> successUsersList;
	private List<RequestUser> failureUsersList;
}
