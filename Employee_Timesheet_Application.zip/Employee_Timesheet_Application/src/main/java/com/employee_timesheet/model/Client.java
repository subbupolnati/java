package com.employee_timesheet.model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="client")
@Data
//This This Model class encapsulates client data fields
public class Client {

	@Id//this annotation used to generate primary key
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "client_generator")
	@SequenceGenerator(name="client_generator", sequenceName = "client_seq", allocationSize=1)
	private int clientId;
	private boolean active;
	private String address;
	private String clientName;
	private String contactNo;
	private String createdBy;
	private LocalDate createdDate;
	private String email;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;

}
