package com.employee_timesheet.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity//This Annotations class like Entity model class
@Table(name="users")
@Data
@NoArgsConstructor
@AllArgsConstructor
//This This Model class encapsulates users data fields
public class User{
		
	@Id //this annotation used to generate primary key
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_generator")
	@SequenceGenerator(name="user_generator", sequenceName = "user_seq", allocationSize=1)
	private int userId;
	private boolean active;
	private String address;
	private String bankDetails;
	private double compensation;
	private String contactNo;
	private String createdBy;
	private LocalDate createdTime;
	private String designation;
	private String dob;
	private String employerMail;
	private LocalDate endDate;
	private String fileName;
	private String fileType;
	private String firstName;
	private boolean firstTime;
	private String gender;
	private LocalDate joiningDate;
	private String lastModifiedBy;
	private LocalDate lastModifiedDate;
	private String lastName;
	private String machineAssetno;
	private String managerMail;
	@Column(unique=true)
	private String officialMail;
	private String password;
	private String personalMail;
	@Lob
	@Column(name = "profile", length = Integer.MAX_VALUE, nullable = true)
	private String profile;
	private String roles;
	private String userType;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "client_id",nullable = true)
	private Client client;
}
