package com.employee_timesheet.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="leaves")
@Data
public class Leaves {

	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "leave_generator")
	@SequenceGenerator(name="leave_generator", sequenceName = "leave_seq", allocationSize=1)
	private int leaveId;
	private LocalDate date;
	private String leaveType;
	private int ptoHours;
	
}
