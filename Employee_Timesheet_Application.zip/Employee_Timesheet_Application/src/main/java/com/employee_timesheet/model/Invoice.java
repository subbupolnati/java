package com.employee_timesheet.model;

import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="invoice")
@Data
public class Invoice {

	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "invoice_generator")
	@SequenceGenerator(name="invoice_generator", sequenceName = "invoice_seq", allocationSize=1)
	private int invoiceId;
	private String employeeName;
	private String fileName;
	private String fileType;
	@Lob
	private Blob invoice;
	private String month;
	private String processedDate;
	private double rateHours;
	private String status;
	private double totalHours;
	private String uploadedDate;
	private int year;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private User user;
	
}
