package com.employee_timesheet.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="timesheet")
@Data
public class Timesheet {
	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "timesheet_generator")
	@SequenceGenerator(name="timesheet_generator", sequenceName = "timesheet_seq", allocationSize=1)
	private int timesheetId;
	private LocalDate date;
	private String comment;
	private boolean reSubmit;
	private String status;
	private int workingHours;
	@OneToOne(optional = false)
	@JoinColumn(name = "leave_id", referencedColumnName = "leaveId")
	private Leaves leave;
	@OneToOne(optional = false)
	@JoinColumn(name="holiday_id",referencedColumnName = "holidayId")
	private Holiday holiday;
	
}
