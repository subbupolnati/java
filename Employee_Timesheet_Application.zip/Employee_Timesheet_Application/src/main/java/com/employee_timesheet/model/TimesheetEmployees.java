package com.employee_timesheet.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="timesheet_employee")
@Data
public class TimesheetEmployees {

	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "timesheetEmp_generator")
	@SequenceGenerator(name="timesheetEmp_generator", sequenceName = "timesheetEmp_seq", allocationSize=1)
	private int timesheetEmployeeId;
	private LocalDate date;
	private String month;
	private int year;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "user_id")
	private User user;
	@OneToOne(cascade =CascadeType.ALL)
	@JoinColumn(name="timesheet_id")
	private Timesheet timesheet;
	
}
