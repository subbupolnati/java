package com.employee_timesheet.model;

import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
public class ConstantMessage {

	public static final String USER_EXIST="This officialMail already exists in another user";
	public static final String USER_SAVE=" Users successfully saved.";
	public static final String FIND_ALL_USERS="Find all users details";
	public static final String USERS_NOTFOUND="User not found";
	public static final String UPDATE_USERS="Users successfully updated.";
	public static final String INACTIVE_USER="User successfully inactivted";
	public static final String OLD_PASSWORD_NOTMATCHED="old password doesnot match";
	public static final String PASSWORD_CHANGED="User password successfully changed ";
	public static final String PROFILE_PIC_SAVED="User profile pic successfully uploaded";
	public static final String PROFILE_PIC_UNSAVED="User profile pic too large please upload below ";
}
