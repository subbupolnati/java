package com.employee_timesheet.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="manager")
@Data
public class Manager {

	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "manager_generator")
	@SequenceGenerator(name="manager_generator", sequenceName = "manager_seq", allocationSize=1)
	private int managerId;
	private String managerMail;
	private String uid;
	
}
