package com.employee_timesheet.model;

import lombok.AllArgsConstructor;
import lombok.Data;

//This JwtResponse model class encapsulated token details
@Data
@AllArgsConstructor
public class JwtResponse {
	private String token;//This field store token details

}
