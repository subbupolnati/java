package com.employee_timesheet.model;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="manager_tracker")
@Data
public class ManagerTracker {

	@Id
	//this annotation used to automatically generated value
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "managerTracker_generator")
	@SequenceGenerator(name="managerTracker", sequenceName = "managerTracker_seq", allocationSize=1)
	private int managerTrackerId;
	private LocalDate approvalEndDate;
	private int emailCount;
	private LocalDate startDate;
	private String managerUid;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="manager_id")
	private Manager manager;
}
