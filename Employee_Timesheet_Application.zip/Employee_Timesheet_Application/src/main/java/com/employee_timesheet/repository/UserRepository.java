package com.employee_timesheet.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employee_timesheet.model.User;

@Repository
//This interface define userRepository 
public interface UserRepository extends JpaRepository<User,Integer>{
	//this method find by user based n official mail id 
	public User findByOfficialMail(String username);
	//this method find by roles with pagesize and page number 
	Page<User> findByRolesContaining(String roles, Pageable pageable);
}
