package com.employee_timesheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeTimesheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
